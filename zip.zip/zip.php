<?php
$uploadDirectory = __DIR__ . '/injector/';
$errorMessage = '';
date_default_timezone_set('Asia/Kolkata');

// Ensure the target directory exists; create it if not
if (!file_exists($uploadDirectory) || !is_dir($uploadDirectory)) {
    if (!mkdir($uploadDirectory, 0777, true)) {
        die('Failed to create the target directory 🥲');
    }
}

// Handle file upload
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_FILES["file"])) {
    if (!empty($_FILES["file"]["name"])) {
        $targetFilePath = $uploadDirectory . basename($_FILES["file"]["name"]);
        if (move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)) {
            $errorMessage = "File uploaded successfully 🎉";
        } else {
            $errorMessage = "Error uploading file 😵‍💫";
        }
    } else {
        $errorMessage = "Please select a file to upload 💩";
    }
}

// Handle file deletion also password 
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['delete'])) {
    if (isset($_POST['password']) && $_POST['password'] === "4HAXT") {
        $fileToDelete = $_POST['delete'];
        $filePathToDelete = $uploadDirectory . $fileToDelete;

        if (file_exists($filePathToDelete)) {
            if (unlink($filePathToDelete)) {
                $errorMessage = "File '{$fileToDelete}' deleted successfully ✅";
            } else {
                $errorMessage = "Error deleting file '{$fileToDelete}'.";
            }
        } else {
            $errorMessage = "File '{$fileToDelete}' not found 🤡";
        }
    } else {
        $errorMessage = "Incorrect password for deleting file 😤";
    }
}
// Get a list of zip files in the upload directory
$zipFiles = array_filter(scandir($uploadDirectory), function ($file) {
    return pathinfo($file, PATHINFO_EXTENSION) === 'zip';
});
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <style>
    body {
      display: flex;
      min-height: 100vh;
      align-items: center;
      justify-content: center;
      margin: 0;
      background: url('https://uploadvip.top/Backgrounds/Makima.jpg') no-repeat center center fixed;
      background-size: cover;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .container {
      max-width: 600px;
      width: 100%;
      margin: 0 auto;
      padding: 20px;
      background-color: rgba(30, 30, 30, 0.85);
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      display: flex;
      flex-direction: column;
      color: #ffffff;
    }

    h1 {
      color: #00FFFF;
      font-size: 28px;
      text-align: center;
      margin-bottom: 20px;
    }

    h2 {
      color: #ff69b4;
      font-size: 20px;
      margin-bottom: 10px;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 10px;
      align-items: center;
    }

    input[type="file"] {
      padding: 10px;
      background-color: #555555;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    button {
      background-color: #00FF7F;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    button:hover {
      background-color: #00b36f;
    }

    ul {
      list-style-type: none;
      padding: 0;
      margin-top: 20px;
    }

    li {
      margin-bottom: 10px;
      display: flex;
      justify-content: space-between;
      background-color: #333333;
      padding: 10px;
      border-radius: 5px;
    }

    .file-details {
      color: #ffb6c1;
      display: flex;
      flex-direction: column;
    }

    .delete-button, .copy-button {
      padding: 5px 10px;
      border-radius: 5px;
      cursor: pointer;
      border: none;
      transition: background-color 0.3s ease;
    }

    .delete-button {
      background-color: #ff4500;
      color: white;
    }

    .delete-button:hover {
      background-color: #cc3700;
    }

    .copy-button {
      background-color: #007bff;
      color: white;
    }

    .copy-button:hover {
      background-color: #0056b3;
    }

    p {
      margin-top: 20px;
      color: #00FF7F;
      text-align: center;
    }

    @media (max-width: 576px) {
      body {
        flex-direction: column;
      }
    }
  </style>
</head>
<body>
  <main class="container">
    <h1>Upload a file</h1>
    <form action="" method="post" enctype="multipart/form-data">
      <input type="file" name="file" accept=".zip">
      <button type="submit" name="upload">Upload</button>
    </form>

    <h2>Uploaded Zip Files:</h2>
    <ul>
      <?php 
        $files = array_diff(scandir($uploadDirectory), array('.', '..'));
        foreach ($files as $file) :
      ?>
        <li>
          <div class="file-details">
            <?php echo $file; ?>
            (Uploaded on: <?php echo date('Y-m-d H:i:s', filemtime($uploadDirectory . $file)); ?> IST)
          </div>
          <button class="copy-button" onclick="copyToClipboard('<?php echo "https://uploadvip.top/shivam/download.php?file=" . urlencode($file); ?>')">Copy Link</button>
          <button class="delete-button" onclick="confirmDelete('<?php echo $file; ?>')">Delete</button>
        </li>
      <?php endforeach; ?>
    </ul>
    <p><?php echo $errorMessage; ?></p>
  </main>
  <form id="delete-form" action="" method="post" style="display:none;">
    <input type="hidden" name="delete" id="delete-file">
    <input type="hidden" name="password" id="delete-password">
  </form>
  <script>
    function copyToClipboard(link) {
      navigator.clipboard.writeText(link).then(() => {
        alert("Link copied to clipboard successfully ✅");
      }).catch(err => {
        alert("Failed to copy link 😰: " + err);
      });
    }

    function confirmDelete(fileName) {
      var password = prompt("Please enter the password to delete the file:");
      if (password !== null) {
        document.getElementById('delete-file').value = fileName;
        document.getElementById('delete-password').value = password;
        document.getElementById('delete-form').submit();
      }
    }
  </script>
</body>
</html>